local blueLightsaber = {
    prefabAddress = 'Assets/Example/ExtinctionWeaponsPack/Prefabs/BlueLightsaber.prefab',
    displayName = 'Basic Saber'
}
local vadersLightsaber = {
    prefabAddress = 'Assets/Example/ExtinctionWeaponsPack/Prefabs/DarthVaderLightsaber.prefab',
    displayName = 'Vader\'s Saber'
}
local yodasLightsaber = {
    prefabAddress = 'Assets/Example/ExtinctionWeaponsPack/Prefabs/YodasLightsaber.prefab',
    displayName = 'Yoda\'s Saber'
}
local hanSoloGun = {
    prefabAddress = 'Assets/Example/ExtinctionWeaponsPack/Prefabs/HanSolosGun.prefab',
    displayName = 'Han\'s Pistol'
}
local raysGun = {
    prefabAddress = 'Assets/Example/ExtinctionWeaponsPack/Prefabs/RaysGun.prefab',
    displayName = 'Ray\'s Blaster'
}
local chewCrossbow = {
    prefabAddress = 'Assets/Example/ExtinctionWeaponsPack/Prefabs/ChewbaccasCrossbow.prefab',
    displayName = 'Chewie\'s Bowcaster'
}

weaponTable[blueLightsaber.prefabAddress] = blueLightsaber
weaponTable[vadersLightsaber.prefabAddress] = vadersLightsaber
weaponTable[yodasLightsaber.prefabAddress] = yodasLightsaber
weaponTable[hanSoloGun.prefabAddress] = hanSoloGun
weaponTable[raysGun.prefabAddress] = raysGun
weaponTable[chewCrossbow.prefabAddress] = chewCrossbow